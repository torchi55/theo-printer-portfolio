---
name: redline
description: "Turn weak architectural renders - interior or exterior - into ready-to-paste AI edit prompts that add materials, lighting, planting, entourage and atmosphere without moving the architecture. Publishes a bundled browser annotator so the user marks up their renders, reads and triages the renders while they mark, then writes ONE prompt per render and tells them exactly which image to attach. Then runs a correction loop: the user brings the generated image back, re-marks what is wrong, and gets a new prompt. Use when someone shares a render (Rhino, Twinmotion, Enscape, D5, Lumion, Revit, SketchUp) and wants it improved with AI. Triggers on \\\"redline this render\\\", \\\"annotate this render\\\", \\\"make this render better with AI\\\", \\\"fix my render\\\", \\\"/redline\\\", or a render plus intent to improve it. Not for photo retouching, not for generating buildings from scratch"
---


# REDLINE

Weak render in, one paste-ready prompt out. The architecture never moves. Then you iterate.

**This file is the entire tool.** SKILL.md and the annotator are the same document. There is
nothing else to install and no second asset to hunt for.

---

## RUNNING THIS - read first, every session

This file works two ways. Both are live; pick whichever the person has access to.

**Installed as a skill** - drop this file at `skills/redline/SKILL.md`. Typing `/redline`, or
sharing a render and asking to improve it, triggers it automatically. Nothing to upload.
Fastest and the one to use if available.

**Dropped into a chat** - upload this file alongside the renders in a new conversation. Claude
reads it and follows the same protocol. Slower to start, needs no configuration, works for
anyone. This is the office-share path.

### The first response, always

Do these three things in the very first reply, in this order, before any analysis:

1. **Get the annotator in front of them.** Two routes - prefer the first.

   **If they already have `annotator.html` saved locally**, tell them to open it in their
   browser and skip to step 2. It is a self-contained file; double-clicking it works offline
   and costs nothing. Ask once whether they have it before publishing anything. This is the
   better route and the one to nudge regular users toward.

   **Otherwise publish it.** The complete HTML sits at the bottom of this file under
   *ANNOTATOR SOURCE*. Copy it into an artifact **verbatim** - every line, opening `<style>`
   through the closing `</script>`. Never regenerate it from memory, never abbreviate it,
   never "improve" it, never swap in a substitute. The last line is a completeness sentinel -
   if your artifact does not end with it, you truncated, and you must redo it. Then suggest
   they save it locally so future sessions can use the fast route.
2. **Ask for the renders in the chat too**, if they are not already there. You cannot see
   inside the artifact. Without the renders in chat you lose the triage step, which is the most
   valuable thing this skill does. Two places, one drag, no extra effort.
3. **Say the loop out loud in one line** so a first-time user knows where this is going:
   *mark the renders in the tool -> paste the summary back -> get one prompt per render ->
   take each to ChatGPT or Gemini yourself -> bring the results back for corrections.*

Then start reading the renders while they mark.

### What the user does with the tool

**Box** for a rectangular area. **Lasso** to trace an irregular shape. **Arrow** to point at one
object. **Pin** to mark a spot. A few words per mark - "walnut doors", "warmer lighting". They
should not write paragraphs; that is the job here. Every mark gets a disposition: *AI can do it*
/ *Photoshop* / *fix in Rhino*.

They mark every render in one sitting, fill the **Project** tab, hit **Copy for Claude**, paste
back. Then **Download markups**, which writes per frame an overview plus a combined dimmed PNG
at the render's exact pixel size - or an A/B pair where the frame split past six marks.

If the user would rather not draw, offer to propose marks yourself with normalised coordinates
read off the image - but say they are estimates.

---

## The rule that shapes everything

**A preserve clause on every prompt, always.** Evidence: the same model on the same project
redrew a building given a bare "make this photorealistic" - roofline shortened, entry went
three bays to two, camera reframed - and held its geometry given a marked region plus an
explicit preserve clause. Tested again across six frames: a prompt asking for one change
produced four unrequested changes, yet every pendant, mullion, screen rod and chair position
held. **The preserve clause plus the markup PNG is what buys geometry retention. Nothing else
does.** Never emit a prompt without it.

## One prompt per render

Not one per mark. A single generation renders one internally coherent image, so lighting and
contact shadows get computed against materials that actually exist. Chaining passes fights
that, and every detail a single prompt drops, the correction loop puts back.

**The only split rule:** past six marks on one frame, instructions dilute and the model
silently drops the unglamorous ones - joint widths, contact shadows, sheen levels. At seven or
more marks, split into exactly **two** prompts: surfaces and openings first, then objects,
people, light and atmosphere. Never more than two. The annotator flags this and groups the
marks for you. Apply it yourself; don't ask.

---

## Workflow

### 1. Publish the annotator and request the renders

Covered above. It happens in the first response. Do not defer it behind questions.

### 2. Read the renders and triage - while they mark

Read every render. Name what is actually there - "three cone pendants, unlit, over a reception
desk", "one flat beige across the whole facade, no joints", "the floor is an untextured white
void". Being concrete here earns the trust that the prompts will be concrete too.

Sort every problem:

- **Populate** - a model can add or restyle it. Materials, planting, entourage, sky,
  reflections, light pooling, contact shadows.
- **Surgical** - needs a mask in Photoshop. Duplicate geometry, a colour cast, a lens flare, a
  stray object, any composited overlay that was never rendered.
- **Upstream** - no model can supply it. Missing geometry, wrong camera, over-scaled texture
  assignments, ambient occlusion switched off, luminaires modelled without emission, or frames
  rendered with different environment settings than the rest of the set.

**Say plainly when a render is not worth populating.** AI post on a broken render gives a
polished broken render. If Upstream is the bulk of the problems, say so and recommend fixing
them in the modelling software first. An image model will cheerfully re-render anything handed
to it and will never tell the user this. That refusal is the most valuable thing this skill
does.

**Set-level check.** With multiple frames, look for inconsistency *between* them - mismatched
skies, different exposures, textures at different scales. This is Upstream and it makes a set
read as several different buildings. **Post-processing amplifies set inconsistency; it never
resolves it.** Flag it before writing a single prompt.

If the user chooses to proceed without the upstream fix, say once what that costs, then make
the prompts themselves the cross-frame glue: the palette and environment blocks get pasted into
every prompt verbatim, character for character. Say that out loud - if they edit one, they edit
all.

### 3. Interrogate - one batch, after the markup lands

Use AskUserQuestion. **Batch three to six, specific, never a twenty-turn interview.** The marks
tell you what is worth asking about, which is why this comes after them. Skip anything the
renders or the markup already answer. Offer real options with consequences spelled out.

Do not proceed on assumptions about design intent. If the user won't decide, propose a default,
label it clearly as yours, and say it propagates to every frame.

**Project-level, once per set:**
- Where is this, precisely? City and region - it drives planting, sun angle, sky, vernacular.
- Season and time of day - must match the shadows already in the render.
- Weather and mood: clear, high cloud, overcast, just-rained, golden hour?
- Program, and who actually uses it? Drives entourage, props and wear.
- Real material spec, or are you proposing one?
- What is this for - studio review, portfolio, client, competition? Sets how far to push.

**Interior:** ceiling build-up; artificial lighting on or off and at what colour temperature;
one floor material or zoned; furniture specified or placeholder; staged and empty or lived-in.

**Exterior: what actually grows there?** Ask the region, then name real species and confirm
them. Never write "lush landscaping". Rogue Valley Oregon is Oregon white oak, madrone,
ponderosa, manzanita, deergrass - interior oak savanna, not the wet PNW. Sonoran is palo verde,
saguaro, brittlebush. Getting this right is the difference between a render that reads as sited
and one that reads as stock. Also: planting maturity, hardscape and coursing, whether
neighbouring massing is real context, site grade, sky condition.

**If the deliverable is a competition board,** check the brief for AI-disclosure or prohibition
clauses before any work, and weight value range over micro-detail - frames get viewed at
250-400mm wide and a narrow value band goes to mud at that size.

**If the renders belong to a client or an employer,** confirm once that the person is cleared to
run them through a third-party image model. Ask, note the answer, move on. Do not relitigate it.

### 4. Lock the material palette

One named entry per surface class: Floor, Wall, Ceiling/Soffit, Facade/Cladding, Glazing, Metal,
Stone/Hardscape, Millwork. Propose from what the renders already show, then get confirmation. It
goes into every prompt - it is what makes fourteen frames read as one building. Propose, don't
assume. Where a palette entry deliberately overrides what is currently rendered, say so.

### 5. Write the language - this is the actual work

The user types "better lighting". That produces slop. Always give: material and finish,
dimension, colour, placement, and what must not change.

> "Coffee bar" -> a cart.
>
> "Coffee bar along this counter run - walnut floating shelf 8in deep, chrome espresso machine,
> grinder, six stacked stoneware mugs, brass tray" -> presentable.

Never write "improve", "enhance", "make it nicer". Every change names a thing, its material, and
roughly its size.

**Rewrite undirectable adjectives.** "Make this person more attractive" gives the model no
anchor and it will redraw the face - a different person comes back. Rewrite as: photoreal skin
with subsurface tone and visible pores, individually resolved hair strands, real woven fabric
with seams and drape, eyes with moisture and a catchlight - keeping exact pose, position,
height, build and clothing colour, and never altering identity, age or ethnicity. That is what
actually produces an attractive figure.

**Order the changes inside the prompt** - broad surfaces, then openings and views, then objects,
then people, with lighting and atmosphere last. The model reads sequentially and later
instructions dominate.

**Never let a model generate text.** Signage, menu boards, notices, wayfinding, artwork with
lettering - it will hallucinate garbage glyphs. Route these to Surgical and say so.

### 6. Deliver it so it can be used without thinking

Name every frame by **what it is**, never by filename. "The lobby." "The gallery ramp." Then:

    IMAGE 3 - THE LOBBY
    Attach: your original lobby render  +  lobby_MARKUP_combined.png
    Paste this:
    ---
    <the prompt>
    ---

The prompt body:

    Two attachments: image 1 is the render, image 2 is a markup PNG at identical pixel size in
    which everything outside the targets is dimmed and each target is pixel-true and outlined.
    Edit image 1 only; use image 2 solely to locate the targets.

    CHANGE 1 - <region and percentages>: <material, finish, dimension, colour, placement>
    CHANGE 2 - <region and percentages>: <...>
    ...

    DO NOT in this pass: <the specific things adjacent to the targets that must not move>

    OVERALL DIRECTION: <one paragraph>

    MATERIAL PALETTE, MATCH ACROSS ALL SHEETS: <the palette>

    <PRESERVE CLAUSE>

    STANDING RULES: <the user's constraints, plus: nothing moves or resizes; all people keep
    exact pose, position, height, build and clothing colour; never alter identity, age or
    ethnicity; artificial light never overpowers daylight; no text, signage, logos or
    watermarks>

    Change only what this prompt describes. Keep everything else as close to unchanged as
    possible. Output a single edited image at the same aspect ratio as image 1.

**Preserve clause, interior:**

> Preserve the architecture exactly. Do not move or resize walls, window mullions, door
> openings, the ceiling plane or its slope, or the floor level. Do not change the camera angle,
> focal length, or perspective. Match the existing daylight - same direction, same colour
> temperature, same shadow angles. Photorealistic architectural interior photography. No
> stylisation, no watermark, no text.

**Preserve clause, exterior:**

> Preserve the architecture exactly. Do not move or resize the building massing, roofline,
> parapet, window or door openings, mullions, columns, or the site grade. Do not change the
> camera angle, focal length, or perspective. Match the existing daylight - same direction,
> same colour temperature, same shadow angles. Photorealistic architectural photography. No
> stylisation, no watermark, no text.

**Standing rules** ride on every prompt and are never a change of their own. Prefer a standing
rule over a whole-frame change.

### 7. The correction loop - this is what makes it usable

Assume the first output will be 80% right. That is the design, not a failure.

The user takes the prompt to an image model themselves - this tool does not call one:

- **GPT Image (ChatGPT)** - attach both images, paste the prompt. No watermark. Keep each frame
  in its own thread so the conversation carries the output forward as the next input.
- **Nano Banana (Gemini image, AI Studio)** - often more faithful to a written material brief,
  but **stamps a Gemini watermark** the prompt cannot suppress. The model dropdown must be set
  to an *image* model or it replies in prose.

Gemini's free **API** tier is `limit: 0` for image models. The web interfaces are the free path.
**Never handle the user's API key** - not in a file, not in a chat, not in a request.

Then they bring the result back:

1. They drop the generated image into the annotator, mark what is wrong, paste the summary back.
2. **Read the new image against the previous one and name the drift yourself** before responding
   to their marks. Collateral drift is guaranteed - secondary objects near a target shift even
   when the architecture holds. Call it out; they may not have spotted it.
3. Write a **correction prompt** in the same shape, targeting only the marked faults plus any
   drift worth reversing. Tell them plainly: *attach the generated image, not the original.*
4. Repeat. Two or three rounds is normal and expected.

**Know when to stop.** If the same fault survives two correction rounds, the model cannot do it.
Say so and route it to Surgical or Upstream instead of burning a third round.

---

## Hard rules

- Publish the annotator in the first response, verbatim, and ask for the renders in chat at the
  same time.
- One prompt per render. Split into two only past six marks. Never more than two.
- Every prompt carries the preserve clause. No exceptions.
- Only Populate marks become prompt content. Surgical and Upstream go to their own checklists,
  named explicitly.
- Markup PNGs are always at the source's exact pixel dimensions.
- Never let a model generate text or signage.
- A Lasso says roughly where; it is not a mask. Only a Box gets bounded percentage language.
- Name frames by what they are, never by filename.
- Never promise "pixel-identical". An instructed edit re-encodes the whole frame. Only a masked
  Photoshop pass can claim that.

---

## ANNOTATOR SOURCE

Copy everything between the fences into an artifact, verbatim and complete. Do not edit it, do
not shorten it, do not rewrite it from memory. Your artifact must end with the sentinel comment
on the final line; if it does not, you truncated and must redo it.

`````html
<style>
  :root{
    --bg:#0d0f12; --panel:#151920; --line:#252c36; --ink:#e6eaf0; --dim:#8b95a3;
    --accent:#ff5c3d; --ok:#4ade80;
    --f:ui-monospace,SFMono-Regular,Menlo,Consolas,"DejaVu Sans Mono",monospace;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--ink);font:13px/1.5 var(--f)}
  #wrap{display:flex;flex-direction:column;height:100vh;min-height:560px}

  header{display:flex;align-items:center;gap:14px;padding:10px 14px;
    border-bottom:1px solid var(--line);flex-wrap:wrap}
  .brand{font-weight:700;letter-spacing:.22em;font-size:12px}
  .brand span{color:var(--accent)}
  .tools{display:flex;gap:4px}
  button{font:inherit;background:var(--panel);color:var(--ink);border:1px solid var(--line);
    padding:5px 10px;cursor:pointer;border-radius:3px}
  button:hover{border-color:#3a4553}
  button.on{background:var(--accent);border-color:var(--accent);color:#120704;font-weight:700}
  button.go{background:#1d2a20;border-color:#2f5138;color:var(--ok)}
  .sp{flex:1}
  .hint{color:var(--dim);font-size:11px}

  #tray{display:flex;gap:6px;padding:6px 14px;border-bottom:1px solid var(--line);
    overflow-x:auto;min-height:44px;align-items:center}
  #tray:empty::after{content:"no images yet";color:var(--dim);font-size:11px}
  .thumb{height:32px;border:2px solid transparent;cursor:pointer;border-radius:2px;flex:none}
  .thumb.on{border-color:var(--accent)}

  main{flex:1;display:flex;min-height:0}
  #stage{flex:1;display:flex;align-items:center;justify-content:center;
    padding:12px;min-width:0;position:relative}
  #stage.drop{outline:2px dashed var(--accent);outline-offset:-10px}
  canvas{max-width:100%;max-height:100%;cursor:crosshair;background:#000;
    box-shadow:0 0 0 1px var(--line)}
  #empty{position:absolute;text-align:center;color:var(--dim);pointer-events:none;padding:20px}
  #empty b{color:var(--ink);display:block;margin-bottom:6px;letter-spacing:.1em}

  aside{width:330px;flex:none;border-left:1px solid var(--line);display:flex;
    flex-direction:column;min-height:0}
  .tabs{display:flex;border-bottom:1px solid var(--line)}
  .tabs button{flex:1;border:0;border-radius:0;background:transparent;color:var(--dim);
    padding:9px 0;border-bottom:2px solid transparent}
  .tabs button.on{color:var(--ink);border-bottom-color:var(--accent);background:transparent}
  .pane{flex:1;overflow-y:auto;padding:12px;display:none}
  .pane.on{display:block}

  .mark{border:1px solid var(--line);border-radius:3px;margin-bottom:8px;background:var(--panel)}
  .mark.sel{border-color:var(--accent)}
  .mhead{display:flex;align-items:center;gap:7px;padding:7px 8px}
  .num{width:20px;height:20px;border-radius:2px;display:grid;place-items:center;
    font-size:11px;font-weight:700;color:#120704;flex:none}
  .mhead .k{color:var(--dim);font-size:11px;text-transform:uppercase}
  .mbody{padding:0 8px 8px}
  textarea,select,input[type=text]{width:100%;font:inherit;background:#0b0d10;
    color:var(--ink);border:1px solid var(--line);border-radius:3px;padding:5px 6px}
  textarea{resize:vertical;min-height:44px}
  .row{display:flex;gap:5px;margin-top:5px}
  .row select{flex:1;min-width:0}
  .x{background:transparent;border:0;color:var(--dim);padding:2px 5px;cursor:pointer}
  .x:hover{color:var(--accent)}
  .split{margin-top:6px;padding:5px 7px;border:1px dashed #3a4553;border-radius:3px;
    color:var(--accent);font-size:11px}

  label.fld{display:block;margin:9px 0 3px;color:var(--dim);font-size:11px;
    text-transform:uppercase;letter-spacing:.09em}
  .pal label{margin:7px 0 2px}
  #out{white-space:pre-wrap;word-break:break-word;background:#0b0d10;border:1px solid var(--line);
    border-radius:3px;padding:9px;max-height:44vh;overflow:auto;font-size:11px;color:var(--dim)}
  .note{color:var(--dim);font-size:11px;margin:9px 0}
  .warn{color:var(--accent)}
  @media (max-width:820px){
    main{flex-direction:column} aside{width:auto;border-left:0;border-top:1px solid var(--line);
    max-height:46vh} #stage{min-height:230px}
  }
</style>

<div id="wrap">
  <header>
    <div class="brand">RED<span>LINE</span></div>
    <div class="tools" id="tools">
      <button data-t="box" class="on">Box</button>
      <button data-t="lasso">Lasso</button>
      <button data-t="arrow">Arrow</button>
      <button data-t="pin">Pin</button>
    </div>
    <span class="hint" id="tip">drag a box around what you want changed</span>
    <div class="sp"></div>
    <input type="file" id="file" accept="image/*" multiple hidden>
    <button onclick="file.click()">Add images</button>
    <button class="go" onclick="copyBrief()">Copy for Claude</button>
    <button onclick="dlMarkups()">Download markups</button>
  </header>

  <div id="tray"></div>

  <main>
    <div id="stage">
      <canvas id="cv"></canvas>
      <div id="empty"><b>DROP YOUR RENDERS HERE</b>
        or click Add images | nothing leaves your browser</div>
    </div>
    <aside>
      <div class="tabs">
        <button class="on" data-p="marks">Marks</button>
        <button data-p="project">Project</button>
        <button data-p="export">Export</button>
      </div>
      <div class="pane on" id="p-marks"></div>
      <div class="pane" id="p-project"></div>
      <div class="pane" id="p-export">
        <div class="note">Paste this into your Claude chat. It carries your notes and where
          each mark sits - not the raw outline points, which Claude does not need.</div>
        <button class="go" onclick="copyBrief()">Copy for Claude</button>
        <div id="out" style="margin-top:9px"></div>
      </div>
    </aside>
  </main>
</div>

<script>
const CATS=["Materials/Finish","Facade/Cladding","Glazing","Lighting","Furniture","Fixtures",
  "Millwork/Built-in","Art","Signage","Textiles","Vegetation/Landscape","Paving/Hardscape",
  "Sky/Atmosphere","Entourage/People","Site"];
const COL={"Materials/Finish":"#4dd2ff","Facade/Cladding":"#ff8a3d","Glazing":"#5ec8ff",
  "Lighting":"#ffc93d","Furniture":"#ff4d3d","Fixtures":"#ff6f9c","Millwork/Built-in":"#ffa04d",
  "Art":"#ffffff","Signage":"#b9c2cc","Textiles":"#ff8fb8","Vegetation/Landscape":"#5ee08a",
  "Paving/Hardscape":"#9aa4b0","Sky/Atmosphere":"#7fd4ff","Entourage/People":"#c78bff",
  "Site":"#8fe0c8"};
/* Group A runs first in a split: broad surfaces and openings.
   Group B runs second: objects, people, light, atmosphere. */
const GROUP_A=new Set(["Materials/Finish","Facade/Cladding","Glazing","Millwork/Built-in",
  "Paving/Hardscape"]);
const PAL=["Floor","Wall","Ceiling/Soffit","Facade/Cladding","Glazing","Metal",
  "Stone/Hardscape","Millwork"];
const TIPS={box:"drag a box around what you want changed",
  lasso:"draw around an irregular shape - release to close",
  arrow:"drag from empty space to the thing you mean",
  pin:"click the spot"};
const SPLIT_AT=7;   /* seven or more populate marks on one frame forces two prompts */

let sheets=[], cur=-1, tool="box", sel=null, drawing=null;
const proj={name:"",direction:"",always:"",palette:{}};
const cv=document.getElementById("cv"), cx=cv.getContext("2d");
const stage=document.getElementById("stage");

/* ---------- loading ---------- */
document.getElementById("file").onchange=e=>load([...e.target.files]);
["dragenter","dragover"].forEach(t=>stage.addEventListener(t,e=>{
  e.preventDefault();stage.classList.add("drop")}));
["dragleave","drop"].forEach(t=>stage.addEventListener(t,e=>{
  e.preventDefault();stage.classList.remove("drop")}));
stage.addEventListener("drop",e=>load([...e.dataTransfer.files]));
addEventListener("paste",e=>load([...(e.clipboardData?.files||[])]));

function load(files){
  files.filter(f=>f.type.startsWith("image/")).forEach(f=>{
    const im=new Image();
    im.onload=()=>{
      sheets.push({name:f.name,img:im,w:im.naturalWidth,h:im.naturalHeight,
        kind:"",title:"",marks:[]});
      if(cur<0)cur=0;
      tray();paint();panes();
    };
    im.src=URL.createObjectURL(f);
  });
}
function tray(){
  const t=document.getElementById("tray");t.innerHTML="";
  sheets.forEach((s,i)=>{
    const im=document.createElement("img");
    im.src=s.img.src;im.className="thumb"+(i===cur?" on":"");im.title=s.name;
    im.onclick=()=>{cur=i;sel=null;tray();paint();panes()};
    t.appendChild(im);
  });
  document.getElementById("empty").style.display=sheets.length?"none":"block";
}

/* ---------- tools ---------- */
document.getElementById("tools").onclick=e=>{
  const b=e.target.closest("button");if(!b)return;
  tool=b.dataset.t;
  [...e.currentTarget.children].forEach(c=>c.classList.toggle("on",c===b));
  document.getElementById("tip").textContent=TIPS[tool];
};
document.querySelector(".tabs").onclick=e=>{
  const b=e.target.closest("button");if(!b)return;
  document.querySelectorAll(".tabs button").forEach(c=>c.classList.toggle("on",c===b));
  document.querySelectorAll(".pane").forEach(p=>
    p.classList.toggle("on",p.id==="p-"+b.dataset.p));
  if(b.dataset.p==="export")document.getElementById("out").textContent=brief();
};

/* ---------- canvas ---------- */
function fit(){
  if(cur<0)return;
  const s=sheets[cur], box=stage.getBoundingClientRect();
  const k=Math.min((box.width-24)/s.w,(box.height-24)/s.h,1);
  cv.width=Math.max(1,Math.round(s.w*k));cv.height=Math.max(1,Math.round(s.h*k));
}
function paint(){
  if(cur<0){cv.width=cv.height=0;return}
  fit();
  const s=sheets[cur];
  cx.drawImage(s.img,0,0,cv.width,cv.height);
  s.marks.forEach(m=>drawMark(cx,m,cv.width,cv.height,m===sel));
  if(drawing)drawMark(cx,drawing,cv.width,cv.height,true);
}
addEventListener("resize",paint);

function drawMark(c,m,W,H,hot){
  const col=COL[m.cat]||"#ff4d3d", u=Math.max(W,H)/1000, lw=Math.max(2,Math.round(3.2*u));
  c.save();
  c.strokeStyle=col;c.fillStyle=col;c.lineWidth=hot?lw+1:lw;
  c.lineJoin="round";c.lineCap="round";
  const P=m.pts.map(p=>[p[0]*W,p[1]*H]);
  if(m.kind==="box"){
    c.strokeRect(P[0][0],P[0][1],P[1][0]-P[0][0],P[1][1]-P[0][1]);
  }else if(m.kind==="lasso"){
    c.beginPath();P.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.stroke();
  }else if(m.kind==="arrow"){
    const a=P[0],b=P[P.length-1];
    c.beginPath();c.moveTo(...a);c.lineTo(...b);c.stroke();
    c.beginPath();c.arc(b[0],b[1],7*u,0,7);c.fill();
  }else{
    c.beginPath();c.arc(P[0][0],P[0][1],11*u,0,7);c.fill();
  }
  const bb=bounds(m), x=bb[0]*W, y=bb[1]*H, bw=26*u, bh=22*u;
  c.fillRect(x,Math.max(0,y-bh),bw,bh);
  c.fillStyle="#120704";c.font=`700 ${Math.round(14*u)}px ui-monospace,monospace`;
  c.textAlign="center";c.textBaseline="middle";
  c.fillText(m.n,x+bw/2,Math.max(0,y-bh)+bh/2);
  c.restore();
}
function bounds(m){
  const xs=m.pts.map(p=>p[0]), ys=m.pts.map(p=>p[1]);
  return [Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)];
}

/* ---------- drawing ---------- */
function at(e){
  const r=cv.getBoundingClientRect();
  const t=e.touches?e.touches[0]:e;
  return [Math.min(1,Math.max(0,(t.clientX-r.left)/r.width)),
          Math.min(1,Math.max(0,(t.clientY-r.top)/r.height))];
}
function start(e){
  if(cur<0)return; e.preventDefault();
  const p=at(e), s=sheets[cur];
  if(tool==="pin"){ add({kind:"pin",pts:[p]}); return; }
  drawing={kind:tool,pts:[p],cat:"Materials/Finish",n:s.marks.length+1};
}
function move(e){
  if(!drawing)return; e.preventDefault();
  const p=at(e);
  if(drawing.kind==="lasso"){
    const l=drawing.pts[drawing.pts.length-1];
    if(Math.hypot(p[0]-l[0],p[1]-l[1])>0.006)drawing.pts.push(p);   // thin while drawing
  }else drawing.pts[1]=p;
  paint();
}
function end(){
  if(!drawing)return;
  const d=drawing; drawing=null;
  if(d.kind==="box"){
    if(d.pts.length<2){paint();return}
    const [a,b]=d.pts;
    if(Math.abs(a[0]-b[0])<0.012||Math.abs(a[1]-b[1])<0.012){paint();return}
    d.pts=[[Math.min(a[0],b[0]),Math.min(a[1],b[1])],[Math.max(a[0],b[0]),Math.max(a[1],b[1])]];
  }
  if(d.kind==="lasso"&&d.pts.length<4){paint();return}
  if(d.kind==="arrow"&&d.pts.length<2){paint();return}
  add(d);
}
cv.addEventListener("mousedown",start); addEventListener("mousemove",move);
addEventListener("mouseup",end);
cv.addEventListener("touchstart",start,{passive:false});
cv.addEventListener("touchmove",move,{passive:false}); addEventListener("touchend",end);

function add(m){
  const s=sheets[cur];
  const k={n:s.marks.length+1,kind:m.kind,pts:m.pts,cat:m.cat||"Materials/Finish",
    disp:"populate",note:"",order:s.marks.length+1};
  s.marks.push(k); sel=k; panes(); paint();
  const ta=document.querySelector(`textarea[data-n="${k.n}"]`);
  if(ta){ta.scrollIntoView({block:"nearest"});ta.focus()}
}
function renumber(){
  const s=sheets[cur];
  s.marks.sort((a,b)=>a.order-b.order).forEach((m,i)=>{m.n=i+1;m.order=i+1});
}
function pops(s){return s.marks.slice().sort((a,b)=>a.order-b.order)
  .filter(m=>m.disp==="populate")}
function groupA(list){return list.filter(m=>GROUP_A.has(m.cat))}
function groupB(list){return list.filter(m=>!GROUP_A.has(m.cat))}

/* ---------- panels - built once, mutated in place so typing never loses focus ---------- */
function panes(){
  const box=document.getElementById("p-marks"); box.innerHTML="";
  if(cur<0){box.innerHTML='<div class="note">Add an image to start marking.</div>';
    projPane();return}
  const s=sheets[cur];
  if(!s.marks.length)
    box.innerHTML='<div class="note">No marks yet. Pick a tool and draw on the image.<br><br>'
      +'Keep notes short - a few words. "walnut doors", "warmer lighting". Claude turns them '
      +'into the full instruction.</div>';
  s.marks.forEach(m=>{
    const d=document.createElement("div");
    d.className="mark"+(m===sel?" sel":"");
    d.onmousedown=()=>{sel=m;paint();
      document.querySelectorAll(".mark").forEach(x=>x.classList.remove("sel"));
      d.classList.add("sel")};
    const head=document.createElement("div");head.className="mhead";
    head.innerHTML=`<div class="num" style="background:${COL[m.cat]||"#ff4d3d"}">${m.n}</div>
      <span class="k">${m.kind}</span><div class="sp" style="flex:1"></div>`;
    const del=document.createElement("button");del.className="x";del.textContent="\u2715";
    del.onclick=()=>{s.marks=s.marks.filter(x=>x!==m);if(sel===m)sel=null;
      renumber();panes();paint()};
    head.appendChild(del);

    const body=document.createElement("div");body.className="mbody";
    const ta=document.createElement("textarea");
    ta.placeholder="what is this, and what should change?";
    ta.value=m.note; ta.dataset.n=m.n;
    ta.oninput=()=>{m.note=ta.value};                       // no re-render on keystroke
    const row=document.createElement("div");row.className="row";
    const cat=document.createElement("select");
    CATS.forEach(c=>cat.add(new Option(c,c,false,c===m.cat)));
    cat.onchange=()=>{m.cat=cat.value;head.querySelector(".num").style.background=COL[m.cat];
      panes();paint()};
    const dis=document.createElement("select");
    [["populate","AI can do it"],["surgical","Photoshop"],["upstream","fix in Rhino"]]
      .forEach(([v,l])=>dis.add(new Option(l,v,false,v===m.disp)));
    dis.onchange=()=>{m.disp=dis.value;panes()};
    row.append(cat,dis);
    body.append(ta,row);
    d.append(head,body);box.appendChild(d);
  });
  const p=pops(s);
  if(p.length>=SPLIT_AT){
    const w=document.createElement("div");w.className="split";
    w.textContent=`${p.length} populate marks - this frame splits into TWO prompts. `
      +`A (surfaces/openings): ${groupA(p).length}. B (objects/people/light): ${groupB(p).length}.`;
    box.appendChild(w);
  }
  projPane();
}
function projPane(){
  const p=document.getElementById("p-project");
  if(p.dataset.built){syncSheetFields();return}
  p.dataset.built="1";
  p.innerHTML=`
    <label class="fld">Project name</label><input type="text" id="f-name">
    <label class="fld">This image is</label>
    <select id="f-kind"><option value="">- interior or exterior -</option>
      <option value="interior">interior</option><option value="exterior">exterior</option></select>
    <label class="fld">What is this view?</label><input type="text" id="f-title"
      placeholder="lobby looking toward the cafe">
    <label class="fld">General direction (every pass, every image)</label>
    <textarea id="f-dir" placeholder="where it is, what it should feel like, season and time of day"></textarea>
    <label class="fld">Always - standing rules</label>
    <textarea id="f-alw" placeholder="e.g. all people photoreal but same pose; keep lighting restrained; nothing moves or resizes"></textarea>
    <label class="fld">Material palette</label><div class="pal" id="f-pal"></div>`;
  const pal=document.getElementById("f-pal");
  PAL.forEach(k=>{
    const l=document.createElement("label");l.textContent=k;l.className="fld";
    const i=document.createElement("input");i.type="text";i.dataset.k=k;
    i.value=proj.palette[k]||"";
    i.oninput=()=>{proj.palette[k]=i.value};
    pal.append(l,i);
  });
  const bind=(id,f)=>{const el=document.getElementById(id);el.oninput=()=>f(el.value);
    el.onchange=()=>f(el.value)};
  bind("f-name",v=>proj.name=v); bind("f-dir",v=>proj.direction=v);
  bind("f-alw",v=>proj.always=v);
  bind("f-kind",v=>{if(cur>=0)sheets[cur].kind=v});
  bind("f-title",v=>{if(cur>=0)sheets[cur].title=v});
  syncSheetFields();
}
function syncSheetFields(){
  if(cur<0)return;
  document.getElementById("f-kind").value=sheets[cur].kind||"";
  document.getElementById("f-title").value=sheets[cur].title||"";
}

/* ---------- export ---------- */
function loc(m){
  const b=bounds(m), p=v=>Math.round(v*100);
  if(m.kind==="box")return `box, ${p(b[0])}-${p(b[2])}% from left, ${p(b[1])}-${p(b[3])}% from top`;
  if(m.kind==="lasso")return `outline (irregular), roughly ${p(b[0])}-${p(b[2])}% from left, `
    +`${p(b[1])}-${p(b[3])}% from top`;
  if(m.kind==="arrow"){const h=m.pts[m.pts.length-1];
    return `arrow pointing at ${p(h[0])}% from left, ${p(h[1])}% from top`}
  return `pin at ${p(m.pts[0][0])}% from left, ${p(m.pts[0][1])}% from top`;
}
function brief(){
  if(!sheets.length)return "(no images loaded yet)";
  const L=["REDLINE MARKUP - paste this to Claude and ask it to write the prompts",""];
  if(proj.name)L.push(`Project: ${proj.name}`);
  if(proj.direction)L.push(`Direction: ${proj.direction}`);
  if(proj.always)L.push(`Always: ${proj.always}`);
  const pal=Object.entries(proj.palette).filter(([,v])=>v&&v.trim());
  if(pal.length){L.push("Palette:");pal.forEach(([k,v])=>L.push(`  ${k}: ${v}`))}
  L.push("");
  sheets.forEach(s=>{
    const p=pops(s);
    L.push(`--- ${s.name}  (${s.w}x${s.h}${s.kind?", "+s.kind:""})`);
    if(s.title)L.push(`    ${s.title}`);
    if(!s.marks.length){L.push("    (no marks)");L.push("");return}
    s.marks.slice().sort((a,b)=>a.order-b.order).forEach(m=>{
      L.push(`  ${m.n}. [${m.cat}] ${m.disp==="populate"?"":"("+m.disp+") "}${loc(m)}`);
      L.push(`     "${(m.note||"(no note)").trim()}"`);
    });
    if(p.length>=SPLIT_AT){
      L.push(`    >> ${p.length} populate marks - SPLIT into two prompts.`);
      L.push(`       A (surfaces/openings): ${groupA(p).map(m=>m.n).join(", ")||"none"}`);
      L.push(`       B (objects/people/light): ${groupB(p).map(m=>m.n).join(", ")||"none"}`);
    }else{
      L.push(`    >> ${p.length} populate marks - ONE prompt for this frame.`);
    }
    L.push("");
  });
  L.push("Write ONE prompt per render, not one per mark - a single generation computes",
    "lighting and contact shadows against materials that actually exist. Split a frame into",
    "exactly two prompts only where flagged above. Every prompt carries the preserve clause.",
    "Surgical and upstream marks do not become prompt content - list them separately.",
    "Keep the architecture fixed. Ask me anything you need before writing.");
  return L.join("\n");
}
function copyBrief(){
  const t=brief();
  document.getElementById("out").textContent=t;
  navigator.clipboard?.writeText(t).then(
    ()=>flash("copied - paste it into Claude"),
    ()=>flash("select the text in the Export tab and copy it"));
}
function flash(msg){
  const el=document.getElementById("tip"); const old=el.textContent;
  el.textContent=msg; el.classList.add("warn");
  setTimeout(()=>{el.textContent=old;el.classList.remove("warn")},2600);
}

/* markup PNGs, drawn at the image's true pixel size so marks line up exactly.
   `only` may be a single mark OR an array of marks - an array produces one dimmed
   field with several pixel-true windows, which is what a one-prompt-per-render pass needs. */
function markup(s,only){
  const c=document.createElement("canvas");c.width=s.w;c.height=s.h;
  const g=c.getContext("2d");
  g.drawImage(s.img,0,0,s.w,s.h);
  const list = only ? (Array.isArray(only)?only:[only]) : null;
  if(list&&list.length){
    const keep=document.createElement("canvas");keep.width=s.w;keep.height=s.h;
    const kg=keep.getContext("2d");kg.fillStyle="#fff";
    list.forEach(m=>{
      if(m.kind==="lasso"){
        kg.beginPath();m.pts.forEach((p,i)=>i?kg.lineTo(p[0]*s.w,p[1]*s.h)
          :kg.moveTo(p[0]*s.w,p[1]*s.h));kg.closePath();kg.fill();
      }else if(m.kind==="box"){
        const b=bounds(m);
        kg.fillRect(b[0]*s.w,b[1]*s.h,(b[2]-b[0])*s.w,(b[3]-b[1])*s.h);
      }else{
        const p=m.pts[m.pts.length-1], r=Math.max(s.w,s.h)*0.09;
        kg.beginPath();kg.arc(p[0]*s.w,p[1]*s.h,r,0,7);kg.fill();
        if(m.kind==="arrow"){const a=m.pts[0];
          kg.lineWidth=r*0.55;kg.strokeStyle="#fff";kg.lineCap="round";
          kg.beginPath();kg.moveTo(a[0]*s.w,a[1]*s.h);kg.lineTo(p[0]*s.w,p[1]*s.h);kg.stroke()}
      }
    });
    // dim everything except the targets, leaving each target pixel-true
    const sh=document.createElement("canvas");sh.width=s.w;sh.height=s.h;
    const sg=sh.getContext("2d");
    sg.fillStyle="rgba(10,12,15,0.62)";sg.fillRect(0,0,s.w,s.h);
    sg.globalCompositeOperation="destination-out";sg.drawImage(keep,0,0);
    g.drawImage(sh,0,0);
  }
  (list||s.marks).forEach(m=>drawMark(g,m,s.w,s.h,false));
  return c;
}
function dl(canvas,name){
  canvas.toBlob(b=>{
    const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=name;
    a.click();setTimeout(()=>URL.revokeObjectURL(a.href),4000);
  },"image/png");
}
function dlMarkups(){
  if(!sheets.length)return flash("load an image first");
  let n=0, delay=0;
  sheets.forEach(s=>{
    const stem=s.name.replace(/\.[^.]+$/,"").replace(/[^a-z0-9]+/gi,"-").toLowerCase();
    const p=pops(s);
    setTimeout(()=>dl(markup(s,null),`${stem}_MARKUP_overview.png`),delay);delay+=320;
    if(!p.length)return;
    if(p.length>=SPLIT_AT){
      const A=groupA(p), B=groupB(p);
      if(A.length){setTimeout(()=>dl(markup(s,A),`${stem}_MARKUP_A_surfaces.png`),delay);
        delay+=320;n++}
      if(B.length){setTimeout(()=>dl(markup(s,B),`${stem}_MARKUP_B_objects.png`),delay);
        delay+=320;n++}
    }else{
      setTimeout(()=>dl(markup(s,p),`${stem}_MARKUP_combined.png`),delay);delay+=320;n++;
    }
    p.forEach((m,i)=>{
      setTimeout(()=>dl(markup(s,m),`${stem}_MARKUP_single_${i+1}.png`),delay);delay+=320;
    });
  });
  flash(n?`downloading ${n} prompt markups + singles + overviews`
        :"no populate marks to export");
}
panes();
</script>
<!-- REDLINE ANNOTATOR - END OF FILE - v2 -->
`````

---

*End of REDLINE. One file, two install paths, no other assets.*