---
name: redline
description: Turn weak architectural renders - interior or exterior - into AI edit prompts that add materials, lighting, planting, entourage and atmosphere without moving the architecture. Critiques the renders, locks a material palette, points the user at a local markup tool to box and lasso what they want changed, then writes one prompt plus one markup PNG per image. Use when someone shares a render (Rhino, Twinmotion, Enscape, D5, Lumion, Revit, SketchUp) and wants it improved with AI. Triggers on "redline this render", "annotate this render", "make this render better with AI", "fix my render", "/redline", or a render plus intent to improve it. Not for photo retouching, not for generating buildings from scratch.
---

# REDLINE

Weak render in, ordered single-change edit prompts out. The architecture never moves.

Everything runs in this chat plus any image model the user already pays for. No API key, no
install, no local tooling.

## The two rules that shape everything

**One image, one prompt.** Every populate mark on a frame goes into that frame's single
prompt, as a numbered list of changes keyed to the numbered markup. The user runs it once and
gets one image back. Simplicity is the point - do not split a frame into multiple passes.

The cost is real and you must manage it in the writing: asking for a coffee bar, a plant and
a lamp in one breath is how you get a blended blob. **Defend against it by numbering.** Each
change names its own mark number, its own material, its own dimension, and ends before the
next begins. Never let two changes share a sentence.

**A preserve clause on every prompt, always.** Evidence: the same model on the same project
redrew a building when given a bare "make this photorealistic" - roofline shortened, entry
went three bays to two, camera reframed - and held its geometry when given a marked region
plus an explicit preserve clause. **The prompt discipline is what buys geometry retention,
not the choice of model.** Never emit a prompt without it.

## Workflow

The whole loop, in order: **rough render out of Rhino/Revit/Twinmotion/D5 -> upload to this
chat for critique -> lock the palette -> mark up the same raw images in the annotator ->
one prompt + one markup PNG per image -> run each in GPT Image against the raw render.**

### 1. Look, and say what you see

Read every render before anything else. Name what is actually there - "three cone pendants,
unlit, over a reception desk", "one flat beige across the whole facade, no joints", "the floor
is an untextured white void". Being concrete here is what earns the user's trust that the
prompts will be concrete too.

Then sort every problem you find:

- **Populate** - a model can add or restyle it. Materials, planting, entourage, sky,
  reflections, light pooling, contact shadows.
- **Surgical** - needs a mask in Photoshop. Duplicate geometry, a colour cast, a stray object.
- **Upstream** - no model can supply it. Missing geometry, wrong camera, a frame rendered with
  different settings than the rest of the set.

**Say plainly when a render is not worth populating.** AI post on a broken render gives a
polished broken render. If Upstream is the bulk of the problems, recommend fixing them in the
modelling software first. This is the most valuable thing this skill does, and it is the one
thing the user cannot get from a generic image prompt.

### 2. Interrogate before writing a single prompt

The user knows their project; you do not. Ask, then write. **Batch three to six questions at a
time, specific, never a twenty-turn interview.** Skip anything the renders already answer.

Do not proceed on assumptions about design intent. If the user will not decide, propose a
default, label it clearly as yours, and say that it propagates to every frame.

**Project-level, once per set:**
- Where is this, precisely? City and region - it drives planting, sun angle, sky, vernacular.
- What season and time of day? It must match the shadows already in the render; you cannot
  relight from scratch without drifting into generate territory.
- Weather and mood: clear, high cloud, overcast, just-rained, golden hour?
- What is the program, and who actually uses it? Drives entourage, props and wear.
- Is there a real material spec, or are you proposing one?
- What is this for - studio review, portfolio, client, competition? Sets how far to push.

**Interior:**
- What is the ceiling meant to be - exposed structure, plaster, acoustic panel, wood?
- Should the artificial lighting be ON? What colour temperature?
- One floor material throughout, or zoned?
- Are the furniture pieces specified, or generic placeholders you can restyle?
- How lived-in: staged and empty, or actively in use with clutter and wear?

**Exterior:**
- **What actually grows there?** Ask the region, then name real species and confirm them.
  Never write "lush landscaping". A Pacific-Northwest courtyard is Oregon white oak, madrone,
  vine maple, ceanothus, sword fern. A Sonoran one is palo verde, saguaro, brittlebush. Getting
  this right is the difference between a render that reads as sited and one that reads as
  stock.
- Newly planted or mature? Changes canopy size, trunk calliper, how much building is hidden.
- Hardscape material and coursing pattern?
- Are the neighbouring buildings real context or placeholder massing?
- Is the site grade correct in the render, or is that an Upstream fix?
- Sky: clear, high cirrus, broken cloud, overcast?

### 3. Lock the material palette

Do this **before** they open the annotator - the palette is what they mark against.

One named entry per surface class: Floor, Wall, Ceiling/Soffit, Facade/Cladding, Glazing,
Metal, Stone/Hardscape, Millwork. Propose from what the renders already show, then get
confirmation. It goes into every prompt - it is what makes fourteen frames read as one building
rather than fourteen buildings. The palette is the user's decision; propose, don't assume.

### 4. Send them to the annotator

The tool ships with this skill at `assets/annotator.html`. Resolve its real path on **this**
machine and hand the user a clickable `file://` URL - do not paste a path from memory or from
another user's setup. It is normally under the skills directory:

```
<skills-dir>/redline/assets/annotator.html
  Windows   file:///C:/Users/<user>/.claude/skills/redline/assets/annotator.html
  mac/Linux file:///Users/<user>/.claude/skills/redline/assets/annotator.html
```

It is self-contained - no network, no libraries, and images never leave their browser. That
also means **you cannot see what they load into it**, which is why the renders had to come
into this chat at step 1. If the file is not on disk for this user, publish
`assets/annotator.html` as an artifact instead.

**Warn them the tool has no save.** A refresh or a closed tab loses every mark and every
Project-tab field. They should finish a set in one sitting and hit Download markups plus Copy
for Claude before leaving.

They load **the same raw renders** they showed you. Tell them: **Box** for a rectangular area,
**Lasso** to trace an irregular shape, **Arrow** to point at one object, **Pin** to mark a
spot. A few words per mark - "walnut doors", "warmer lighting". They should not write
paragraphs; that is your job.

**Push them to set the disposition dropdown per mark.** It defaults every mark to `populate`,
so anything they forget arrives labelled as AI work even when it is a Rhino fix. If a set comes
back all-populate, suspect the default and re-sort it with them against what you saw at step 1.

They fill the **Project** tab (direction, standing rules, material palette), hit **Copy for
Claude**, and paste the result back. It is a compact text summary - marks, notes, and where
each sits as percentages - not raw outline coordinates, which you do not need.

Then **Download markups**: one PNG per image at the render's exact pixel size, all that image's
populate marks outlined and numbered, everything outside them dimmed 42%, the marked regions
left pixel-true.

If the user would rather not draw, offer to propose the marks yourself with normalised 0-1
coordinates read off the image - but say the coordinates are estimates and offer the tool for
anything that needs precision.

### 5. Write the language - this is the actual work

The user types "better lighting". That produces slop. Always give: material and finish,
dimension, colour, placement, and what must not change.

> "Coffee bar" -> a cart.
>
> "Coffee bar along this counter run - walnut floating shelf 8in deep, chrome espresso machine,
> grinder, six stacked stoneware mugs, brass tray" -> presentable.

Never write "improve", "enhance", "make it nicer". Every numbered item names a thing, its
material, and roughly its size.

**One change per numbered item, never two.** "Stone top and walnut below, and put books and a
coffee on it" is a material change and a props change - they get separate numbers even if the
user drew one mark. "Walnut door, and make the person realistic" is two subjects. Split them
into their own numbered lines and say why. The numbering is what stops the blend.

**Rewrite undirectable adjectives.** "Make this person more attractive" gives the model no
anchor and it will redraw the face. Rewrite as: photoreal skin, resolved hair, real fabric
weave - keeping exact pose, position, height and clothing colour.

**Order the items within the prompt:** broad surfaces first, then objects, then people, with
lighting and atmosphere **last**. Same reason as before - a broad instruction read late
overwrites a small one read early.

Emit one prompt per image, in this shape:

```
<image name> - one prompt, <k> changes
Attach: the raw render  +  <slug>_MARKUP.png

The attached markup shows numbered regions. Change only those regions.

1. <marked region 1, where it is in percentages> - <material, finish, dimension,
   colour, placement, and what must not change>
2. <marked region 2 ...>
...

Overall direction for this project:
  <the one-paragraph direction>

Match this material palette across all images in this set:
  <the palette>

<PRESERVE CLAUSE - see below>

<any standing rules the user gave>

Change only what the numbered items describe. Every unmarked part of the frame
stays as close to unchanged as possible.

Save result as: <slug>_redlined.jpg
```

**Preserve clause, interior:**

> Preserve the architecture exactly. Do not move or resize walls, window mullions, door
> openings, the ceiling plane or its slope, or the floor level. Do not change the camera angle,
> focal length, or perspective. Match the existing daylight - same direction, same colour
> temperature, same shadow angles. Photorealistic architectural interior photography. No
> stylisation, no watermark, no text.

**Preserve clause, exterior:**

> Preserve the architecture exactly. Do not move or resize the building massing, roofline,
> parapet, window or door openings, mullions, or the site grade. Do not change the camera
> angle, focal length, or perspective. Match the existing daylight - same direction, same
> colour temperature, same shadow angles. Photorealistic architectural photography. No
> stylisation, no watermark, no text.

**Standing rules** are constraints that ride on every prompt and are never a numbered item of
their own - "all people photoreal but same pose", "keep lighting restrained", "nothing moves or
resizes". Put them in every prompt.

### 6. Run - three things per image

The user takes each image's prompt to an image model and attaches **the raw render + that
image's markup PNG**, then pastes the prompt. Three things, every time. Both models are
validated on real frames:

- **GPT Image (ChatGPT)** - no watermark.
- **Nano Banana (Gemini image, Google AI Studio)** - often more faithful to a written material
  brief, but **stamps a Gemini watermark** the prompt cannot suppress. In AI Studio the model
  dropdown must be set to an *image* model; a text model will reply in prose describing what it
  would do instead of producing an image.

Gemini's free **API** tier is `limit: 0` for every image model, so scripted runs need billing.
The web interfaces are the free path.

Never handle the user's API key - not in a file, not in a chat, not in a request.

**Check the output against the numbered list.** Expect two failure modes, and name them for the
user up front so they know what to look for:

- **Dropped items.** With several changes in one prompt, a model will quietly skip one. Read the
  result against the numbers. If item 4 did not happen, re-run the same prompt with only the
  missed items - do not accept a partial.
- **Collateral drift.** Secondary objects near a marked region - furniture spacing, artwork
  position, shelf contents, a seated figure's posture - shift slightly even when the
  architecture holds.

If a result comes back blended - two changes fused into one object - that is the cost of the
one-prompt-per-image shape. Fix it by re-running with the offending items split out, not by
rewording.

**If the geometry drifted, tighten the box - do not lengthen the preserve clause.** A bigger
marked region invites more reinterpretation. A longer clause does not counteract it. This is
the most common wrong instinct.

**Warn them about output dimensions.** These models return their own fixed sizes, not the
render's. A 1600x900 frame comes back at whatever the model emits and may be cropped or
letterboxed to a different aspect. Tell the user to check the returned aspect ratio before
building a board around it, and to keep the raw render as the master.

## Hard rules

- One image, one prompt. Every change inside it is numbered and self-contained.
- Every prompt carries the preserve clause. No exceptions.
- Only Populate marks become changes. Surgical and Upstream go to their own checklists.
- Markup PNGs are always at the source's exact pixel dimensions.
- The prompt always runs against the **raw render**, never a previous output. No chaining.
- A Lasso says roughly where; it is not a mask. Only a Box gets bounded percentage language.
- Never promise "pixel-identical". An instructed edit re-encodes the whole frame. Only a masked
  Photoshop pass can claim that.
